// App Exercise - Progress Updates

//  Call the function a number of times, passing in different values of `steps` and `goal`. Observe the printouts and make sure what is printed to the console is what you would expect for the parameters passsed in.

func progressUpdate(steps: Int, goal: Int){
    if steps < (goal * 10 / 100){
        print("You're off to a good start.")
    }else if steps < (goal / 2){
        print("You're almost halfway there!")
    }else if steps < (goal * 90 / 100){
        print("You're over halfway there!")
    }else if steps < goal{
        print("You're almost there!")
    }else{
        print("You beat your goal!")
    }
}


progressUpdate(steps: 500, goal: 1000)
progressUpdate(steps: 10, goal: 100)
progressUpdate(steps: 7000, goal: 8000)

//  Your fitness tracking app is going to help runners stay on pace to reach their goals. Write a function called pacing that takes four `Double` parameters called `currentDistance`, `totalDistance`, `currentTime`, and `goalTime`. Your function should calculate whether or not the user is on pace to hit or beat `goalTime`. If yes, print "Keep it up!", otherwise print "You've got to push it just a bit harder!"


func pacing(currentDistance: Double, totalDistance: Double, currentTime: Double, goalTime: Double){
    let pace = currentTime/(currentDistance/totalDistance)
    if pace < goalTime {
        print("Keep it up!")
    } else {
        print("You've got to push it just a bit harder!")
    }
}

















